import gradio as gr
import matplotlib.pyplot as plt
from predictor import predict_single

MODEL_PATH = "weights.json"

def predict(url):
    url = (url or "").strip()
    if not url:
        # Empty state
        return {"fake": 0.0, "real": 0.0}, "Please enter a URL.", None, []

    probs = predict_single(url, MODEL_PATH)
    verdict = "FAKE" if probs["fake"] >= 0.5 else "REAL"
    msg = f"**Prediction:** {verdict}\n\n- fake: {probs['fake']:.3f}\n- real: {probs['real']:.3f}"

    # Probability bar figure
    fig = plt.figure(figsize=(4, 2.5), dpi=120)
    plt.bar(["fake", "real"], [probs["fake"], probs["real"]])
    plt.ylim(0, 1)
    plt.title("Probability")
    for i, v in enumerate([probs["fake"], probs["real"]]):
        plt.text(i, min(v + 0.03, 0.97), f"{v:.2f}", ha="center")
    plt.tight_layout()

    chip = "High Risk" if probs["fake"] >= 0.8 else ("Suspicious" if probs["fake"] >= 0.5 else "Likely Safe")
    # HighlightedText expects spans like [(text, label)]
    chip_spans = [(chip, "risk")]
    return probs, msg, fig, chip_spans

with gr.Blocks(
    title="Fake URL Detector",
    theme=gr.themes.Soft(primary_hue="red", neutral_hue="gray"),
    fill_height=True
) as demo:
    with gr.Row():
        gr.Markdown("# Fake URL Detector")
    gr.Markdown(
        "Paste a URL below. The app loads minimal 'trained' weights from `weights.json` "
        "and shows probabilities for **fake** vs **real**."
    )

    with gr.Row():
        with gr.Column(scale=2, min_width=480):
            url_in = gr.Textbox(
                label="URL",
                placeholder="e.g. https://secure-login.example.xyz/verify"
            )
            with gr.Row():
                predict_btn = gr.Button("Predict", variant="primary")
                clear_btn = gr.Button("Clear")

        with gr.Column(scale=1, min_width=380):
            with gr.Group():
                probs_out = gr.Label(label="Probabilities")
                msg_out = gr.Markdown("")
                plot_out = gr.Plot(label="")
                chip_out = gr.HighlightedText(
                    label="Risk",
                    combine_adjacent=True
                )

    def clear():
        return "", {"fake": 0.0, "real": 0.0}, "", None, []

    predict_btn.click(fn=predict, inputs=url_in, outputs=[probs_out, msg_out, plot_out, chip_out])
    clear_btn.click(fn=clear, inputs=None, outputs=[url_in, probs_out, msg_out, plot_out, chip_out])

    gr.Markdown(
        "---\n"
        "Note: This is a heuristic demo. For real-world phishing defense, combine content analysis, "
        "threat intelligence, and user education."
    )

if __name__ == "__main__":
    demo.launch(share=True)
