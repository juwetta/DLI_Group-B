import json
import math
import re
from urllib.parse import urlparse

SUSPICIOUS_TLDS = {
    "zip","xyz","top","work","country","gq","tk","cf","ml","ga","men","loan","download",
    "click","review","party","racing","date","stream","church","kim","mom","fit","rest","biz"
}
SHORTENER_DOMAINS = {
    "bit.ly","goo.gl","t.co","tinyurl.com","ow.ly","is.gd","buff.ly","cutt.ly","rebrand.ly","rb.gy"
}
PHISHY_KEYWORDS = {
    "login": 2.0, "verify": 2.0, "update": 1.6, "secure": 1.2, "confirm": 1.4,
    "account": 1.0, "billing": 1.2, "password": 2.0, "support": 0.6, "wallet": 1.4
}

# ---------- NEW: allowlist helpers ----------
ALLOWLIST = {
    "youtube.com", "youtu.be", "google.com", "apple.com", "microsoft.com",
    "github.com", "facebook.com", "x.com", "twitter.com", "linkedin.com"
}
# minimal handling for “second-level ccTLDs”
S2_CCTLD = {"co.uk","com.au","com.my","co.jp","com.sg","com.br"}

def base_domain(host: str) -> str:
    parts = host.split(".")
    if len(parts) < 2:
        return host
    tld2 = parts[-2] + "." + parts[-1]
    if tld2 in S2_CCTLD and len(parts) >= 3:
        return parts[-3] + "." + tld2
    return tld2
# -------------------------------------------

def sigmoid(x: float) -> float:
    try:
        if x >= 0:
            z = math.exp(-x)
            return 1.0 / (1.0 + z)
        else:
            z = math.exp(x)
            return z / (1.0 + z)
    except OverflowError:
        return 0.0 if x < 0 else 1.0

def extract_features(url: str) -> dict:
    # Normalize
    url = url.strip()
    if not re.match(r'^[a-z]+://', url):
        url = "http://" + url  # add a scheme if missing so urlparse works

    parsed = urlparse(url)

    host = parsed.netloc.lower()
    path_q = (parsed.path or "") + ("?" + parsed.query if parsed.query else "")
    full = host + path_q

    # Features
    has_https = 1.0 if parsed.scheme == "https" else 0.0
    url_len = len(url)
    num_dots = host.count(".")
    num_hyphens = full.count("-")
    has_at = 1.0 if "@" in full else 0.0
    has_pct = 1.0 if "%" in full else 0.0
    has_ip = 1.0 if re.search(r"(?:\d{1,3}\.){3}\d{1,3}", host) else 0.0
    tld = host.split(".")[-1] if "." in host else ""
    has_suspicious_tld = 1.0 if (tld in SUSPICIOUS_TLDS) else 0.0
    is_shortener = 1.0 if any(host.endswith(d) for d in SHORTENER_DOMAINS) else 0.0

    # ---------- CHANGED: keyword scoring only on path+query (not host) ----------
    keyword_score = 0.0
    lower_pathq = (parsed.path or "").lower() + ("?" + parsed.query.lower() if parsed.query else "")
    for kw, w in PHISHY_KEYWORDS.items():
        if kw in lower_pathq:
            keyword_score += w
    # ---------------------------------------------------------------------------

    # ---------- NEW: allowlist feature ----------
    bd = base_domain(host)
    is_allowlisted = 1.0 if bd in ALLOWLIST else 0.0
    # -------------------------------------------

    # Light normalization for length
    len_scaled = min(url_len / 100.0, 3.0)  # cap

    return {
        "bias": 1.0,
        "has_https": has_https,
        "len_scaled": len_scaled,
        "num_dots": float(num_dots),
        "num_hyphens": float(num_hyphens),
        "has_at": has_at,
        "has_pct": has_pct,
        "has_ip": has_ip,
        "has_suspicious_tld": has_suspicious_tld,
        "is_shortener": is_shortener,
        "keyword_score": keyword_score,
        "is_allowlisted": is_allowlisted,   # NEW
    }

class SimpleURLModel:
    def __init__(self, weights: dict):
        self.weights = weights

    @classmethod
    def from_file(cls, path: str):
        with open(path, "r", encoding="utf-8") as f:
            weights = json.load(f)
        return cls(weights)

    def predict_proba(self, url: str):
        feats = extract_features(url)
        # Linear combination
        z = 0.0
        for name, value in feats.items():
            w = self.weights.get(name, 0.0)
            z += w * value
        p_fake = sigmoid(z)
        p_real = 1.0 - p_fake
        return {"fake": float(p_fake), "real": float(p_real)}

def predict_single(url: str, model_path: str):
    model = SimpleURLModel.from_file(model_path)
    return model.predict_proba(url)
