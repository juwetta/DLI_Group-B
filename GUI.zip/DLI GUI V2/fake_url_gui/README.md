# 🔍 Fake URL Detection GUI (Gradio + Streamlit)

This project provides two simple GUIs that **load trained weights** (`weights.json`), allow a **single URL prediction**, and display **probability scores**.

---

## 🚀 Quickstart

```bash
python -m pip install -r requirements.txt

# Run the Streamlit app
streamlit run app_streamlit.py

# Run the Gradio app (prints a local link)
python app_gradio.py

# To get Public Access (Run it in a second terminal while your app is running)

For Gradio (port 7860): .\cloudflared.exe tunnel --url http://127.0.0.1:7860

For Streamlit (port 8501): .\cloudflared.exe tunnel --url http://127.0.0.1:8501

You will get a public like: https://random-subdomain.trycloudflare.com


---
```
# 📂 Files

predictor.py – lightweight URL feature extractor + logistic model

weights.json – toy "trained" weights JSON

app_gradio.py – Gradio interface (share=True, can also use Cloudflare)

app_streamlit.py – Streamlit interface (st.file_uploader, st.button, st.write)

cloudflared.exe – binary for tunneling (to make your app publicly accessible)

requirements.txt – Python dependencies

README.md – this file
