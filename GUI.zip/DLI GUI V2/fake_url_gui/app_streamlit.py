import streamlit as st
from predictor import predict_single

st.set_page_config(page_title="Fake URL Detector", page_icon="🔎", layout="centered")

st.markdown("<h1 style='text-align:center;margin-bottom:0'>Fake URL Detector</h1>", unsafe_allow_html=True)
st.caption("Lightweight demo scoring using a heuristic model loaded from weights.json")

with st.container():
    col1, col2 = st.columns([2, 1], gap="medium")

    with col1:
        st.subheader("Input")

        # Simple text input (no examples)
        url_input = st.text_input(
            "URL",
            placeholder="e.g. https://secure-login.example.xyz/verify",
        )

        # Optional: load URL from a .txt file (single line)
        uploaded = st.file_uploader("Or upload a .txt file with a single URL", type=["txt"])
        if uploaded is not None:
            try:
                contents = uploaded.read().decode("utf-8", errors="ignore").strip().splitlines()
                if contents:
                    url_input = contents[0].strip()
                    st.info(f"Loaded from file: {url_input}")
                else:
                    st.warning("Uploaded file appears empty.")
            except Exception as e:
                st.error(f"Failed to read file: {e}")

        go = st.button("Predict", type="primary", use_container_width=True)

    with col2:
        st.subheader("Result")
        verdict_placeholder = st.empty()
        bar_placeholder = st.empty()
        detail_placeholder = st.empty()
        badge_placeholder = st.empty()

if go:
    if not url_input.strip():
        st.warning("Please provide a URL.")
    else:
        probs = predict_single(url_input.strip(), "weights.json")
        fake_p = probs["fake"]
        real_p = probs["real"]
        verdict = "FAKE" if fake_p >= 0.5 else "REAL"

        verdict_placeholder.markdown(f"### Prediction: **{verdict}**")
        bar_placeholder.progress(min(max(fake_p, 0.0), 1.0), text=f"Fake probability: {fake_p:.2f}")
        detail_placeholder.write({"fake": round(fake_p, 3), "real": round(real_p, 3)})

        if fake_p >= 0.8:
            badge_placeholder.warning("High Risk")
        elif fake_p >= 0.5:
            badge_placeholder.warning("Suspicious")
        else:
            badge_placeholder.success("Likely Safe")

st.divider()
st.caption("This demo is for educational purposes.")
